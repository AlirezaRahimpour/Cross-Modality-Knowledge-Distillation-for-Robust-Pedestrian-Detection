weights files are saved teacher_Net
